---
title: 실습5. 제목
weight: 60
pre: "<b>5. </b>"
---

**실습에 대한 설명을 적습니다.** <br/><br/>

### 큰제목
1. 순서를 가이드합니다.

**Automate responses**

**Build a Monitoring Plan: Alerting and Response**

Monitoring for Operational Outcomes Sansa Bailish is focused on outages, reliability, and getting better sleep. There is a known issue with image trends; when the instances are rebooted the application doesn’t restart. Too frequently Sansa has received a late night call to get online and restart the application. The user experience lead is very frustrated with the downtime associated to these incidents. They need to be detected sooner and resolved faster.

Sansa is looking for a monitoring solution to detect the incident (the reboot event), and a way to trigger an automated recovery.

**Create and Automate Responses**

Create a Runbook to Resolve the Error

**6.1 Resolve the error manually**

1. Depending on your browser, you will see an error showing that the page cannot be loaded.
1. Add /admin to the end of the URL from the CloudFormation output.
1. Click on images in the menu to see the images with the error.
1. Delete the image by pressing the x next to the image with no tags or errors in the tags.
1. Click Home on the navigation bar at the top **NOTE:** The application should be working again.

**6.2 Automate Responses using Lambda**

1. Navigate to the Lambda Console
1. Click on the ExampleCorpErrorEvent Lambda function
1. Under Basic settings
   1. Set Timeout to 30 seconds
   1. Under Network
      1. Select the VPC created earlier with a 10.180.0.0/16 CIDR block for VPC
      1. Select …App Subnet (AZ1) under Subnets
      1. Select …App Subnet (AZ2) under Subnets
      1. Select …AppHostSecurityGroup… under Security groups
1. Click on the Save button

**6.3 Validate - Ensure the response has the desired outcome**

1. Log in to ExampleCorp using the URL that you made a note of earlier (CloudFormation Output) in a new browser tab.
1. Enter admin@admin.com for email
1. Enter Password123for Password
1. Click Login
1. Click Upload Image
1. Click Select Image
1. Find break\_app.jpg in your filesystem
1. Click Upload
1. It will break again, but it should recover in a few seconds
1. Keep an eye on the Lambda monitoring page

**6.4: Bonus Content: Review the outcomes in CloudWatch**

1. Click on View logs in CloudWatch
1. Expand parts of the logs to see what happened.
1. The Lambda got invoked
1. You can see the SNS Message
1. Then you see that 2 rows were deleted
1. Finally the Lambda execution finishes with some summary statistics.
1. Click on Alarms
1. Select ImageErrorAlarm
1. View the history see the Alarm State update and the Action to notify SNS which then calls the Lambda function.

What have we achieved? - We have answered three monitoring needs, one for each of our teams. - We have provided insight to the quality of the end user experience by creating a image tag confidence metric for the business team. - We have provided insight to issues and potential development needs by providing the development team (DevOps) with error and warning metrics. - We have provided a mechanism for the operations team (SRE) to use an event trigger to automatically remediate an outage causing issue in the environment.

How did we create an automatic remediation? - Knowing the log entry that indicates that the application has failed and is in a state from which it can be recovered we created a metric. - Using that metric we created an alarm that notifies via an SNS topic. - We have a Lambda function that is subscribed to that SNS topic that creates a CloudWatch Event in response. - We created a CloudWatch rule that triggers on our Lambda initiated CloudWatch event and invokes run command. - Our run command invocation uses a command document we created to execute the start up script on our server restoring it to an operating state.

We have created something of a Rube Goldberg machine to achieve that outcome. In doing so we have demonstrated the use of logs and how to get more value out of them, the use of events, and the triggering of actions in response to events; all enabled by CloudWatch.


---
<p align="left">
© 2020 Amazon Web Services, Inc. 또는 자회사, All rights reserved.
</p>
