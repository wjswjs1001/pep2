---
title: 실습5. 제목
weight: 60
pre: "<b>5. </b>"
---

**실습에 대한 설명을 적습니다.** <br/><br/>

### 큰제목
1. 순서를 가이드합니다.

**Clean Up**

**Lab tear down**

To remove all the resources configured and deployed as part of this lab perform the following:

1. Navigate to the CloudFormation console at this link
   1. Select your stack, choose Actions, and choose Delete stack
   1. This will delete all resources created by the CloudFormation template
1. Navigate to the Logs page on the CloudWatch console at this link
   1. Select /aws/lambda/ExampleCorpRebootedEvent, then choose Actions, then choose Delete log group, and finally choose Yes, Delete to delete the Log Group
   1. Select application.log, then choose Actions, then choose Delete log group, and finally choose Yes, Delete to delete the Log Group
   1. Select boot.log, then choose Actions, then choose Delete log group, and finally choose Yes, Delete to delete the Log Group
   1. Select messages, then choose Actions, then choose Delete log group, and finally choose Yes, Delete to delete the Log Group
   1. Select production.log, then choose Actions, then choose Delete log group, and finally choose Yes, Delete to delete the Log Group
1. Navigate to the Metrics page on the CloudWatch console at this link
   1. CloudWatch does not support metric deletion. Metrics expire based on the retention schedules which can be found at this link
1. Navigate to the Alarms page on the CloudWatch console at this link
   1. Select ExampleCorpRebootedAlarm by checking the box on the left in its row.
   1. Choose Actions, choose Delete, and finally choose Yes, Delete to delete the Alarm
1. Navigate to the Dashboards page of the CloudWatch console at this link
   1. Choose ExampleCorp
   1. Choose Actions, choose Delete dashboard, and finally when prompted select Delete dashboard to confirm that you wish to delete your dashboard.

**References: ExampleCorp**

A mock workload for a fictitious company.

- Source code: <https://github.com/horsfieldsa/example-corp-app>
- Admin interface: http:///admin
- Admin user: admin@admin.com
- Admin password: Password123

**End of Lab Exercises**

**Thank you for using this lab.**


---
<p align="left">
© 2020 Amazon Web Services, Inc. 또는 자회사, All rights reserved.
</p>
