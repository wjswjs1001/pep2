---
title: 실습4. 제목
weight: 50
pre: "<b>4. </b>"
---

**실습에 대한 설명을 적습니다.** <br/><br/>

### 큰제목
1. 순서를 가이드합니다.

**Generate metrics from logs**

**Generate Metrics from Logs**

Traditional application development emits events in the form of logs. Use CloudWatch we can generate metrics from our logs using pattern matching. By generating metrics based on observed log messages we can increase the value of our CloudWatch logs by providing visualizations of the metric data through dashboard, and providing alerts when metrics breach baseline thresholds. Using the AWS CLI or API you can [publish your own custom metrics](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/publishingMetrics.html).

Metric filters are created using the same [filter and pattern syntax](https://docs.aws.amazon.com/console/cloudwatch/logs/patternSyntax) that is used when [browsing log streams in the console](https://docs.aws.amazon.com/AmazonCloudWatch/latest/logs/Working-with-log-groups-and-streams.html).

***Create a Confidence metric***

Monitoring for Business Outcomes Titus Grone wants to know that ExampleCorp is delighting our customers. Feedback from the customer indicates that accuracy of items identified in the upload images is the greatest source of satisfaction when it works well, and frustration when it does not. Focus groups indicate that it is better to not have misidentified (low confidence) objects.

He wants to track the image recognition confidence levels as a measure of how accurate the ExampleCorp application is performing. He will use this information to help determine where to focus development efforts.

**4.1 Create the Log Metric**

1. Navigate to the CloudWatch **Logs** dashboard at this [link](https://console.aws.amazon.com/cloudwatch/home#logs:).
1. In the contents pane, select the **application.log** group by clicking on the radio button next to it, and then choose Create Metric Filter. ![Create Metric Filter](images/Aspose.Words.c0e37e3b-bc2f-432e-97a1-de93a0d3684d.001.jpeg)
   1. On the **Define Logs Metric Filter** screen, for **Filter Pattern**, type:
   1. [logType, myTimestamp, severity, delim1, delim2, type, action, for, Image, imgNum, Name, imgTags, Confidence, cValue]
   1. To test your filter pattern, for **Select Log Data to Test**, select the log group to test the metric filter against, and then choose Test Pattern.
   1. Under **Results**, CloudWatch Logs displays a message showing how many occurrences of the filter pattern were found in the log file. To see detailed results, click Show test results.
   1. Choose **Assign Metric** ![Define Log Metric](images/Aspose.Words.c0e37e3b-bc2f-432e-97a1-de93a0d3684d.002.jpeg)
1. On the **Create Metric Filter and Assign a Metric** screen,
   1. For Filter Name type *confidenceLevels*
   1. Under **Metric Details**, for **Metric Namespace**, type *ApplicationLogMetrics*
   1. For **Metric Name**, type *cValue*
   1. Choose **Show advanced metric settings**
   1. For **Metric Value** choose *$cValue*.
   1. Leave the **Default Value** undefined, and then choose **Create Filter**. ![Assign Metric](images/Aspose.Words.c0e37e3b-bc2f-432e-97a1-de93a0d3684d.003.jpeg)

**4.2 Review the resulting metrics**

1. Navigate to metrics in the left side navigation bar of the CloudWatch console or by clicking this [link](https://console.aws.amazon.com/cloudwatch/home?#metricsV2:).
1. Under **Custom Namespaces** you will see your **ApplicationLogMetrics** namespace.
   1. Chose **Metrics with no dimensions**
   1. Then choose **Metrics with no dimensions**
   1. Then select **cValue**
1. Choose the **Graphed Metrics** tab and examine the differences in reported values when you change the **Statistic** in use by selecting alternatives from the pull down list beneath it.
1. Change the **Period** to **10 Seconds** and the **Statistic** to **Average** and examine the differences in reported values.

**4.3 Create a dashboard**

1. Choose Actions in to top right corner of the page and choose Add to dashboard
1. In the Add to dashboard dialog
   1. Under Select a dashboard choose Create new and enter ExampleCorp in the Dashboard name text box, and then choose the check mark icon next to the text box to confirm your choice.
   1. Under Select a widget type choose Stacked area
   1. Under Customize widget title replace the prepopulated value cValue with confidence
   1. Choose Add to dashboard
1. On the Dashboards page, choose Save dashboard




<p align="center">
© 2020 Amazon Web Services, Inc. 또는 자회사, All rights reserved.
</p>
